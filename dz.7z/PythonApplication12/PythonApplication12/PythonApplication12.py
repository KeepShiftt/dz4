#a = ((3, 2), 1, (4,), 5)
#b = copy_tuple(a)
#print(a)
#print(a[0] is b[0])

#a = (10, 2.13, "square", 89, 'C')
#b = [1, 2, 3]
#c = list(a)
#d = tuple(b)
#c [10, 2.13, 'square', 89, 'C']
#d (1, 2, 3)
